# -*- coding: utf-8 -*-

from .adapter import Aria2Adapter
