# -*- coding: utf-8 -*-

from PyQt5.QtCore import QObject


class NtService(QObject):
    pass
